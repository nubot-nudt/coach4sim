#include "nubot/world_model/strategyinfo.h"

StrategyInfo::StrategyInfo()
{
}
